<?php

/**
 * Child Theme
 *
 */

function fildisi_child_theme_setup() {

}
add_action( 'after_setup_theme', 'fildisi_child_theme_setup' );


//Omit closing PHP tag to avoid accidental whitespace output errors.
